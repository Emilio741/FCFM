setwd("C:/Users/pc/Documents/ESTADISTICA APLICADA")#carpeta
tm<-read.table("Perdidasdesastresnaturales.csv",sep=",", header=T)
tm
#Convertimos en serie de tiempo
per<-ts(tm$Insured, start=2000, end=2020, frequency= 1 )
#Clasificar
plot(per,ylab="Mil millones de dolares",xlab="A�o",main = "Perdidas Aseguradas en Mil Millones
     de Dolares del 2000-2020" )
acf(per)
pacf(per)
#Paso1:Clasificacion
##Tendencia en media
    #Reviso Tendencia Lineal
    tl<-lm(per~time(per))
    summary(tl)
    plot(per, main  = " Modelo Lineal",xlab = "A�o")
    abline(tl,col="magenta")    
    #y estimada=-6236.416+3.138x
    
    #Reviso Tendencia Cuadratica
    tc<-lm(per~poly(time(per), degree=2, raw=T),data=per)
    summary(tc)
    plot(per,main = " Modelo Cuadr�tico",xlab = "A�o")  
    lines(as.numeric(time(per)),fitted.values(tc), col="blue") 
    coefficients(tc)
    #y estimada=-5.17e5+5.17e2x-1.26e-1x^2    
    
    #Reviso Tendencia exponencial
    y.<-log(per)#transformacion de y
    te<-lm(y.~time(per))#modelo lineal asociado
    summary(te)
    beta0<-exp(coef(te)[1])# y est=-106.06+.05481x
    y.gorro<-beta0*exp(coef(te)[2]*time(per)) #y est=8.6937e-47*e^(.05481x)
    plot(per,main = " Modelo Exponencial",xlab = "A�o")
    lines(as.numeric(time(per)),y.gorro, col="blue")
    
    #Reviso tendencia potenciay gorro=B0X^B1
    #transformacion a usar: x' y y'
    x1.<-log(time(per))
    y1.<-log(per)
    tp<-lm(y1.~x1.)#modelo lineal asociado
    summary(tp) #y est=-834.1+110.2x
    coef(tp)[1]
    B0<-exp(coef(tp)[1])
    B0#y estimado=2.22e-284x^86.58
    y.est.p<-B0*time(per)^coef(tp)[2]
    plot(per,main = "Modelo Potencia",xlab = "A�o")
    lines(as.numeric(time(per)), y.est.p,col="magenta")
    
    #Reviso tendencia Logaritmo
    x11.<-log(time(per))
    tl<-lm(per~x11.)    
    summary(tl)
     #Y est=-47912+6308x   
    #y est=-47912+6038lnx
    y.est<--47912+6038*(log(time(per)))
    plot(per,main= "Modelo Logaritmo",xlab = "A�o")
    lines(as.numeric(time(per)), y.est,col="magenta")
    
    #Reviso tendencia Reciproco
    a�orec<-1/time(per)
    frecrec<-1/per    
    tr<-lm(frecrec~a�orec)
    summary(tr)
    #y est=-2.2597+4580.9316x  
    #y esti=x/(-2.2597x+4580.9316)
    yest<-time(per)/(-2.2597*time(per)+4580.9316)
    plot(per,main = "Modelo Recriproco",xlab = "A�o")
    lines(as.numeric(time(per)), yest,col="magenta")
    ##Comparando los modelos el que tiene mejor desempe�o es el Reciproco con un ajuste del 41.41%
    plot(per, main="Comparacion de los modelos",ylab=" ",xlab="A�o",ylim=c(30,170))
    abline(tl,col="magenta") 
    lines(as.numeric(time(per)),fitted.values(tc), col="blue")
    lines(as.numeric(time(per)),y.gorro,col="red")
    lines(as.numeric(time(per)),y.est.p,col="brown")
    lines(as.numeric(time(per)),y.est,col="orange")
    lines(as.numeric(time(per)),yest,col="purple")
    legend(x="topleft",legend = c("Modelo lineal","Modelo Cuadratico","Modelo Exponencial"),
           col= c("magenta","blue","red"),lty=c(1,1,1))
    legend(x= "topright",legend = c("Modelo logaritmo","Modelo reciproco"),
           col= c("orange","purple"),lty=c(1,1,1))
    
    #H0:Serie no significante, sin tendencia en media
    #H1:Serie significativa
    #Rechazo H0 si p valor=.000984<alfa=.05
    #Rechazo H0, Serie sin estacionariedad en media
##Tendencia en varianza
    library(tseries)
    adf.test(per,alternative="stationary")
    #H0:Serie no estacionaria en varianza
    #H1:Serie estacionaria en varianza
    #Rechazo H0 si p valor=.153<alfa=.05
    #No Rechazo H0, Serie sin estacionariedad en varianza
##Clasificacion: Serie no estacionaria en media y varianza
    
#paso 2: corregir
    #aplicamos diferencia del logaritmo para corregir tendencia y dispersion
    d=diff(log(per))
    plot(d,main = "Correci�n 1",xlab = "A�o")
    re<-lm(d~time(d))
    summary(re)#no presenta tendencia en media pvalor grande
    #h0: B1=0 vs B1!=0, rechazo h0 si p valor=.8228<alfa=.05
    #No rechazo h0, serie sin tendencia en media
    #la serie es estacionaria en media
    ##varianza
    #cambio en varianza
    adf.test(d, alternative="stationary")#rechazamos h0, estacionaria en varianza
    #clasificacion:serie estacionaria
    #Rechazo H0, si pvalor=.3153<alfa=.05
    #No Rechazo H0, serie con tendencia en varianza
    #La varianza no es estacionaria en varianza
    #Clasificacion:No estacionaria, debido a la varianza
##correcion2
    cor2=diff(d)
    plot(cor2)
    re2<-lm(cor2~time(cor2))
    summary(re2)
    #h0: B1=0 vs B1!=0, rechazo h0 si p valor=.9681<alfa=.05
    #No rechazo h0, serie sin tendencia en media
    #la serie es estacionaria en media
    adf.test(cor2, alternative="stationary")#rechazamos h0, estacionaria en varianza
    #clasificacion:serie estacionaria
    #Rechazo H0, si pvalor=.1264<alfa=.05
    #No Rechazo H0, serie con tendencia en varianza
    #La varianza no es estacionaria en varianza
    #Clasificacion:No estacionaria, debido a la varianza
##correccion3
    cor3=diff(cor2)
    plot(cor3)
    re3<-lm(cor3~time(cor3))
    summary(re3)
    #h0: B1=0 vs B1!=0, rechazo h0 si p valor=.8638<alfa=.05
    #No rechazo h0, serie sin tendencia en media
    #la serie es estacionaria en media
    adf.test(cor3, alternative="stationary")#rechazamos h0, estacionaria en varianza
    #clasificacion:serie estacionaria
    #Rechazo H0, si pvalor=.01717<alfa=.05
    #Rechazo H0, serie sin tendencia en varianza
    #La serie es estacionaria en varianza
    #Clasificacion:serie estacionaria en media y varianza
#Paso3:modelado
    #Modelo AR(lo dejamo en los dos for el modelo ya que al principio buscamos el mejor de los tres con los dos for y nos salio como mejor el modelo AR)
    z<-Inf
    for(j in 0:10){
        for(i in 0:10){
            u<-AIC(arima(cor3, order=c(j,0,i), method="ML"))
            if(z>u ){
                z<-u#aic mas chico
                pq.del.mejor<-c(j,i)#el parametro del modelo
            }
        }
    }
    z #aic del mas chico AP
    pq.del.mejor#el mejor modelo es AP(9) para correcion "cor2" de per
    arima(cor3, order=c(9,0,0), method="ML")
    #expresion matematica: Xt=-2.3778Xt-1-3.9008Xt-2-4.8160Xt-3-5.2365Xt-4-5.2394Xt-5-4.7671Xt-6-3.7830Xt-7-2.24.91Xt-8-.9072Xt-9+et
    #Modelo MA
    t<-Inf
    for(i in 1:10){
        s<-AIC(arima(cor3, order=c(0,0,i), method="ML"))
        if(t>s ){
            t<-s#aic mas chico
            q.del.mejor<-i#el parametro del modelo
        }
    }
    t
    q.del.mejor#MA(4)
    arima(cor3, order=c(0,0,4), method="ML")
    #ARMA
    w<-Inf
    for(j in 1:10){
        for(i in 1:10){
            u<-AIC(arima(cor3, order=c(j,0,i), method="ML"))
            if(w>u ){
                w<-u#aic mas chico
                pq.del.mejor<-c(j,i)#el parametro del modelo
            }
        }
    }
    w #aic del mas chico AP
    pq.del.mejor#el mejor modelo es AP(9) para correcion "cor2" de per
#paso 4:ruido blanco
    ##media cero
    o<-arima(cor3,order=c(9,0,0),method="ML")#datos originales
    ME<-residuals(o)
    mean(ME)
    #media=.00711, como es peque�a podemos decir que es media cero
    #VARIANZA CONSTANTE
    plot(ME, type="p",xlab="A�o",ylab="Residuos",main="Varianza", ylim = c(-0.5,0.5))
    #No demuestra algun tipo de patr�n evidente
    
    #INCORRELACION
    acf(ME, main = 'Autocorrelograma')
    pacf(ME, main = 'Autocorrelograma parcial')
    Box.test(ME)#PVALOR=.2478
    #No rechazo H0 por lo que mis residuales son independientes con 95% de confianza
    
    #NORMALIDAD
    shapiro.test(ME)
    #H0:Los residuales son normales
    #H1:Los residuales no son normales
    #Rechazo H0 si Pvalor es menor a Alfa
    #0.0234<0.05
    #Rechazo H0 y digo que mis residuales no son normales
    
    #Digo que mis residuales son ruido blanco no gaussianos
    
    #PREDICCIONES
    #AP(9)
    prediccionarma<-predict(arima(per, order = c(9,3,0),method = "ML"),n.ahead=5)$pred
    plot(per, main="Predicciones bajo el modelo AP(9) serie original",xlab="A�o",xlim=c(2000,2027), ylim=c(30,180))
    lines(prediccionarma,col="red")
    legend(x = "bottomright", legend = "AP(9)", col = "red",lty=1)
    plot(per,xlim=c(2000,2025),ylim=c(0,180),ylab="Mil millones de dolares",xlab="A�o",
         main = "Predicciones de Perdidas Aseguradas en 
     Mil Millones de Dolares 2021-2025")
    lines(prediccionarma,col="red")
    tt<-seq(from=2000, to=2025, by=1)
    yest<-tt/((-2.2597*tt)+4580.9316) 
    lines(tt,yest,col="purple")
    legend(1999.5,185,legend=c("Predicciones","Modelo Reciproco"),col=c("red","purple"),lty=1:1, cex=0.8)
    #MODELO ASOCIADO
    prediccionarima<-predict(arima(cor3, order = c(9,0,0),method = "ML"),n.ahead=5)$pred
    plot(cor3,xlim=c(2003,2025),ylim=c(-3,5),ylab="Mil millones de dolares",xlab="A�o",
         main = "Predicciones de Perdidas Aseguradas en 
     Mil Millones de Dolares 2021-2025")
    lines(prediccionarima,col="blue")
    legend(2018,5,legend=c("Predicciones"),col=c("blue"),lty=1:2, cex=0.8)

    
    